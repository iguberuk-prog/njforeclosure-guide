globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/gfCn9Mvw7-aRYt_huDAe5/_buildManifest.js",
    "static/gfCn9Mvw7-aRYt_huDAe5/_ssgManifest.js",
    "static/gfCn9Mvw7-aRYt_huDAe5/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3z5q_p4msz2ha.js",
    "static/chunks/15orcrkp-_9ct.js",
    "static/chunks/25o46h8mdjlrg.js",
    "static/chunks/2-5nk792mwq2y.js",
    "static/chunks/turbopack-40o9tf0ao-p96.js"
  ]
};
